"use client";
import { createContext, useContext, useEffect, useState, type FormEvent, type ReactNode } from "react";
import type { Locale } from "./content";
import { translations } from "./translations";
import { journeyCopy } from "./journey-content";
import Dialog from "./site-dialog";
import Icon from "./site-icon";
import "./action-styles.css";

type Enquiry = { name: string; email: string; company: string; interest: string; message: string };
type SiteUI = { locale: Locale; setLocale: (locale: Locale) => void; contactOpen: boolean; openContact: (draft?: Enquiry) => void };
const SiteContext = createContext<SiteUI | null>(null);
export function useSiteUI() {
 const value = useContext(SiteContext);
 if (!value) throw new Error("Site UI provider is missing");
 return value;
}
export default function SiteUIProvider({ children }: { children: ReactNode }) {
 const [locale, setLocale] = useState<Locale>("en");
 const [contactOpen, setContactOpen] = useState(false);
 const [draft, setDraft] = useState<Enquiry | null>(null);
 const [enquiry, setEnquiry] = useState<Enquiry | null>(null);
 const copy = translations[locale];
 const journey = journeyCopy[locale];
 useEffect(() => { document.documentElement.lang = locale; }, [locale]);
  useEffect(() => {
    const keyboard = () => { document.documentElement.dataset.input = "keyboard"; };
    const pointer = () => { document.documentElement.dataset.input = "pointer"; };
    document.addEventListener("keydown", keyboard);
    document.addEventListener("pointerdown", pointer);
    return () => { document.removeEventListener("keydown", keyboard); document.removeEventListener("pointerdown", pointer); };
  }, []);
 function openContact(initialDraft?: Enquiry) { setEnquiry(null); setDraft(initialDraft ?? null); setContactOpen(true); }
  function prepareEnquiry(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const fields = Object.fromEntries(new FormData(event.currentTarget)) as Enquiry;
    setDraft(fields); setEnquiry(fields);
  }
  const mailBody = enquiry ? `${copy.name}: ${enquiry.name}\n${copy.email}: ${enquiry.email}\n${copy.company}: ${enquiry.company}\n${copy.interest}: ${enquiry.interest}\n\n${enquiry.message}` : "";
 return <SiteContext.Provider value={{ locale, setLocale, contactOpen, openContact }}>{children}
 {contactOpen && <Dialog title={copy.dialogTitle} closeLabel={copy.close} onClose={() => setContactOpen(false)}>
      {(!enquiry ? <form onSubmit={prepareEnquiry} className="enquiry-form"><p>{copy.dialogText}</p><div className="form-row"><label>{copy.name} *<input name="name" autoComplete="name" required defaultValue={draft?.name} /></label><label>{copy.email} *<input name="email" type="email" autoComplete="email" required defaultValue={draft?.email} /></label></div><label>{copy.company}<input name="company" autoComplete="organization" defaultValue={draft?.company} /></label><label>{copy.interest}<select name="interest" defaultValue={draft?.interest}>{draft?.interest && ![...copy.products.map(p => p.title), ...journey.services.map(s => s.title), copy.findPartner].includes(draft.interest) && <option>{draft.interest}</option>}<optgroup label={copy.nav[0]}>{copy.products.map((p) => <option key={p.title}>{p.title}</option>)}</optgroup><optgroup label={copy.footerLinks[2]}>{journey.services.map((item) => <option key={item.title}>{item.title}</option>)}<option>{copy.findPartner}</option></optgroup></select></label><label>{copy.message}<textarea name="message" rows={3} maxLength={2000} defaultValue={draft?.message} /></label><div className="form-bottom"><span>* {copy.required}</span><button className="ui-action ui-action--primary" type="submit">{copy.send}<Icon name="arrow" /></button></div></form> : <div className="enquiry-ready" role="status"><span className="ready-check">✓</span><h3>{copy.prepared}</h3><p>{copy.preparedText}</p><dl><dt>{copy.name}</dt><dd>{enquiry.name}</dd><dt>{copy.email}</dt><dd>{enquiry.email}</dd>{enquiry.company && <><dt>{copy.company}</dt><dd>{enquiry.company}</dd></>}<dt>{copy.interest}</dt><dd>{enquiry.interest}</dd>{enquiry.message && <><dt>{copy.message}</dt><dd>{enquiry.message}</dd></>}</dl><div className="ready-actions"><a className="ui-action ui-action--primary" href={`mailto:sales@ics-dryice.com?subject=${encodeURIComponent(`ICS — ${enquiry.interest}`)}&body=${encodeURIComponent(mailBody)}`}>{copy.openEmail}<Icon name="diagonal" /></a><button className="ui-action ui-action--secondary" onClick={() => setEnquiry(null)}>{copy.edit}</button></div></div>)}
 </Dialog>}
 </SiteContext.Provider>;
}
