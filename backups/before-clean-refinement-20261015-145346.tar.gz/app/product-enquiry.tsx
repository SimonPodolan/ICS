"use client";
import { useSiteUI } from "./site-ui";
import type { ReactNode } from "react";

export default function ProductEnquiry({ product, children }: { product?: string; children: ReactNode }) {
  const { openContact } = useSiteUI();
  return <button type="button" className="ui-action ui-action--primary" onClick={() => openContact(product ? {
    name: "", email: "", company: "", interest: product,
    message: `I would like to know more about ${product}.`,
  } : undefined)}>{children}<span aria-hidden="true">↗</span></button>;
}
